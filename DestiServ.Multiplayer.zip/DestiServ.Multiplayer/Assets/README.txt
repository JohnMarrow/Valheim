DestiServ territory flag

The flag is built at runtime from a vanilla piece (pole, wall or the first available building piece) plus a stone pile, a wooden mast and a cloth quad. Valheim's Unity editor is not part of this build, so there is no native AssetBundle. The icon is flag_icon.bmp. The game does not require that file; the prefab generates its own icon and materials.

Do not delete DestiServ.Multiplayer.dll. The visual script lives in that assembly.
